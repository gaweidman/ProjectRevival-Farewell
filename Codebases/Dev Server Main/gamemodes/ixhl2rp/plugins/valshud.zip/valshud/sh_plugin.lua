PLUGIN.name = "Val's Hud"
PLUGIN.author = "Val"
PLUGIN.description = "yea"

ix.util.Include("cl_hooks.lua")
ix.util.Include("cl_skin.lua")